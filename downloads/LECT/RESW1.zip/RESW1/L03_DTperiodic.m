clc
clear all
close all

% define discrete-time vector
n= -20:1:20;

% First signal
subplot(3,1,1)
x1 = cos(2*pi*n);
% plot
stem(n,x1,'k');
% set figure and axes options
set(gcf,'Color','white')
xlabel('Sample')
ylabel('Amplitude')
title('$\cos[2 \pi n]$','Interpreter','latex')
ax = gca;
ax.XTick = [-20:1:20];
grid on
box off

% Second Signal
subplot(3,1,2)
x = cos(pi*n/2) + cos(pi*n/4);
% plot
stem(n,x,'k');
% set figure and axes options
% set figure and axes options
set(gcf,'Color','white')
xlabel('Sample')
ylabel('Amplitude')
title('$\cos[\frac{\pi}{2} n] +\cos[\frac{\pi}{4}n] $','Interpreter','latex')
ax = gca;
ax.XTick = [-14:7:14];
grid on
box off
hold on

% highlight the period
hold on
nn=0:1:7
xx = cos(pi*nn/2) + cos(pi*nn/4);
% plot
stem(nn,xx,'r');

% Third signal
subplot(3,1,3)
n2= -40:1:40;
x2 = 5*sin(6*pi*n2/35)
% plot
stem(n2,x2,'k');
% set figure and axes options
set(gcf,'Color','white')
xlabel('Sample')
ylabel('Amplitude')
title('$5 \sin[6 \pi n/35]$','Interpreter','latex')
ax = gca;
ax.XTick = [-34 0 34];
grid on
box off


