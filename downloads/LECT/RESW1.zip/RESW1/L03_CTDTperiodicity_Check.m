
clc
clear all
close all

%% First Example
subplot(3,1,1)

n1= -20:1:20;
x1DT = cos(2*pi*n1/12);

t1=-20:0.1:20;
x1CT = cos(2*pi*t1/12);

% plot
plot(t1,x1CT,'k')
hold on
stem(n1,x1DT,'b');
% set figure and axes options
set(gcf,'Color','white')
xlabel('t or n')
ylabel('Amplitude')
title('$\cos[2 \pi t/12]$ and $\cos[2 \pi n/12]$','Interpreter','latex')
ax = gca;
ax.XTick = [-20:1:20];
grid on
box off

% highlight the period
hold on
n=0:1:11
a = cos(2*pi*n/12);
t=0:0.1:12;
b = cos(2*pi*t/12);
plot(t,b,'k','Linewidth',2)
hold on
stem(n,a,'r','Linewidth',2);



clc
clear all

%% Second Example
subplot(3,1,2)

n1= -40:1:40;
x1DT = cos(8*pi*n1/31);

t1=-40:0.1:40;
x1CT = cos(8*pi*t1/31);

% plot
plot(t1,x1CT,'k')
hold on
stem(n1,x1DT,'b');
% set figure and axes options
set(gcf,'Color','white')
xlabel('t or n')
ylabel('Amplitude')
title('$\cos[8 \pi t/31]$ and $\cos[8 \pi n/31]$','Interpreter','latex')
ax = gca;
ax.XTick = [ -30 -7.75 0 7.75 30];
grid on
box off

% highlight the period
hold on
n=0:1:30;
a = cos(8*pi*n/31);
t=0:0.1:31/4;
b = cos(8*pi*t/31);
plot(t,b,'k','Linewidth',2)
hold on
stem(n,a,'r','Linewidth',2);

clc
clear all

%% Third Example
subplot(3,1,3)

n1= -60:1:60;
x1DT = cos(n1/6);

t1=-60:0.01:20;
x1CT = cos(t1/6);

% plot
plot(t1,x1CT,'k')
hold on
stem(n1,x1DT,'b');
% set figure and axes options
set(gcf,'Color','white')
xlabel('t or n')
ylabel('Amplitude')
title('$\cos[t/6]$ and $\cos[n/6]$','Interpreter','latex')
ax = gca;
ax.XTick = [ -12*pi 0 12*pi];
ax.XTickLabel = {'-12\pi','0','12\pi'};
grid on
box off

% highlight the period
hold on
t=0:0.1:12*pi;
b = cos(t/6);
plot(t,b,'k','Linewidth',2)

