
close all
clc
clear all

w = -pi:0.01:pi;
H = (1/3)*(1+2.*cos(w));

subplot(2,1,1)
plot(w,abs(H))
set(gcf,'Color','white')
xlabel('\omega (rad/s)')
ylabel('|H(e^{j \omega})|')
title('$H(e^{j \omega}) = \frac{1}{3}(1+2\cos(\omega))$','Interpreter','latex')
ax = gca;
ax.XTick = [ -pi -pi/2 0 pi/2 pi ];
ax.XTickLabel = {'-\pi', '-\pi/2','0','\pi/2','\pi'};
grid on
axis([-pi pi 0 1])

subplot(2,1,2)
plot(w,(angle(H)))
set(gcf,'Color','white')
xlabel('\omega (rad/s)')
ylabel('arg\{H(e^{j \omega})\}')
title('$H(e^{j \omega}) = \frac{1}{3}(1+2\cos(\omega))$','Interpreter','latex')
ax = gca;
ax.XTick = [ -pi -pi/2 0 pi/2 pi ];
ax.XTickLabel = {'-\pi', '-\pi/2','0','\pi/2','\pi'};
axis([-pi pi -pi pi])
ax.YTick = [-pi -pi/2 0 pi/2 pi];
ax.YTickLabel = {'-\pi', '-\pi/2','0','\pi/2','\pi'};
grid on

figure
clear all

w = -pi:0.01:pi;
H = exp(-j.*w./3).*(1/3).*(1+2.*cos(w));

subplot(2,1,1)
plot(w,abs(H))
set(gcf,'Color','white')
xlabel('\omega (rad/s)')
ylabel('|H(e^{j \omega})|')
title('$H(e^{j \omega}) = \frac{e^{-j \omega}}{3}(1+2\cos(\omega))$','Interpreter','latex')
ax = gca;
ax.XTick = [ -pi -pi/2 0 pi/2 pi ];
ax.XTickLabel = {'-\pi', '-\pi/2','0','\pi/2','\pi'};
grid on
axis([-pi pi 0 1])

subplot(2,1,2)
plot(w,(angle(H)))
set(gcf,'Color','white')
xlabel('\omega (rad/s)')
ylabel('arg\{H(e^{j \omega})\}')
title('$H(e^{j \omega}) = \frac{e^{-j \omega}}{3}(1+2\cos(\omega))$','Interpreter','latex')
axis([-pi pi -pi pi])
ax = gca;
ax.XTick = [ -pi -pi/2 0 pi/2 pi ];
ax.XTickLabel = {'-\pi', '-\pi/2','0','\pi/2','\pi'};
ax.YTick = [-pi -pi/2 0 pi/2 pi];
ax.YTickLabel = {'-\pi', '-\pi/2','0','\pi/2','\pi'};
grid on


