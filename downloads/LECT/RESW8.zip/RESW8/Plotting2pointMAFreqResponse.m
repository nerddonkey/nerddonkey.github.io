
close all
clc
clear all

alpha = 0.5;
w = -3*pi:0.01:3*pi;
H = exp(-j.*w./2).*cos(w./2);



subplot(2,1,1)
plot(w,abs(H))
set(gcf,'Color','white')
xlabel('\omega (rad/s)')
ylabel('|H(e^{j \omega})|')
title('$H(e^{j \omega}) = e^{-j \omega/2} \cos(\omega/2)$','Interpreter','latex')
ax = gca;
ax.XTick = [-3*pi -2*pi -pi 0 pi 2*pi 3*pi];
ax.XTickLabel = {'-3\pi','-2\pi','-\pi','0','\pi','2\pi','3\pi'};
grid on
axis([-3*pi 3*pi 0 1])

subplot(2,1,2)
plot(w,angle(H))
set(gcf,'Color','white')
xlabel('\omega (rad/s)')
ylabel('arg\{H(e^{j \omega})\}')
title('$H(e^{j \omega}) = e^{-j \omega/2} \cos(\omega/2)$','Interpreter','latex')
ax = gca;
ax.XTick = [-3*pi -2*pi -pi 0 pi 2*pi 3*pi];
ax.XTickLabel = {'-3\pi','-2\pi','-\pi','0','\pi','2\pi','3\pi'};
grid on
axis([-3*pi 3*pi -pi pi])
ax.YTick = [-pi -pi/2 0 pi/2 pi];
ax.YTickLabel = {'-\pi', '\pi/2','0','\pi/2','\pi'};
grid on