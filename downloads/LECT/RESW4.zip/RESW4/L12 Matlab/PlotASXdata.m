%% PlotASXdata
%% ===========================
%% Script to illustrate plotting of ASX data from 1984 to 2016
%%
%% Created  : 11 July 2016
%% Modified : 11 July 2016
%%
%% Copyright (c) 2016 Salman Durrani.
%% ------------------------------------------------------------

%% load ASX data from 1984 to 2016
clc 
clear all
load ASX

%% plot just the closing value data
% stem(AdjClose)


%% plot the data with dates as axis
figure
% convert date to number for plotting
T = datenum(Date);
stem(T, AdjClose)
% convert axes back to date for potting
datetick('x','yyyy','keeplimits', 'keepticks') 
xlabel('Year')
ylabel('ASX Closing Value - \copyright Yahho finance') 
set(gcf,'Color','white')