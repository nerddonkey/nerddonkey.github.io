
%% impulse response of moving average filter
subplot(2,1,1)
% filter order
N=128;
% difference equation coefficients
a=1;
b=(1/N)*ones(1,N);

% find impulse response
n=[-N:N];
h = impz(b,a,n);

% plot impulse response
stem(n,h,'r')
set(gcf,'Color','white')
xlabel('n')
ylabel('Impulse response h[n]') 

%% output of moving average filter
subplot(2,1,2)
% plot original data: zooming in on 2004-2012 
T = datenum(Date(5000:7000));
plot(T, AdjClose(5000:7000),'k')
datetick('x','yyyy','keeplimits', 'keepticks') 
xlabel('Year')
ylabel('ASX Closing Value - \copyright Yahho finance') 
set(gcf,'Color','white')
hold on

% plot output of moving-average system
y= filter(b,a,AdjClose(5000:7000));
T = datenum(Date(5000:7000));
plot(T, y,'r')

