
%% Example 1
% y[n]-0.5*y[n-1]=x[n]
a=[ 1 -0.5];
b=1;

n=-5:20;
h=impz(b,a,n);
stem(n,h);
set(gcf,'Color','white')
xlabel('n')
ylabel('Impulse response h[n]') 
title('y[n]-0.5*y[n-1]=x[n]')

% check stability
s1 =sum(abs(h))

%% Example 2
% y[n]-(1/3)*y[n-1]=x[n-1]
clear all
figure
a=[1 -1/3];
b=[0 1];

n=-5:20;
h=impz(b,a,n);
stem(n,h);
set(gcf,'Color','white')
xlabel('n')
ylabel('Impulse response h[n]') 
title('y[n]-(1/3)*y[n-1]=x[n-1]')

% check stability
s2 =sum(abs(h))