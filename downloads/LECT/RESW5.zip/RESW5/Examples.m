clc
close all
clear all
%% Example 1: x(t) = exp(-2t), T=2.
k=-20:1:20;
e=exp(1);
ak = (1-e.^(-4))./(4+j.*2.*k.*pi);

ak(21)= 1/4;

Mag = abs(ak);
Ph = angle(ak);

subplot(2,1,1)
stem(k,Mag)
set(gcf,'color','white')
xlabel('k')
ylabel('|a_k|')

subplot(2,1,2)
stem(k,Ph)
set(gcf,'color','white')
xlabel('k')
ylabel('arg\{a_k\}')


%% Example 2: sawtooth waveform in Lec 15
figure
clc
clear all
k=-20:1:20;
w = 4*pi/3;

termA = 2./(3*(k.^2)*(w^2));

termB = exp(-j.*k.*w)-exp(j.*k.*w./2);

termC = 2./(3*j.*k*w);

termD = exp(-j.*k.*w)+0.5.*exp(j.*k.*w./2);

ak = termA.*termB+ termC.*termD
ak(21)=1/4;
Mag = abs(ak);
Ph = angle(ak);

subplot(2,1,1)
stem(k,Mag)
set(gcf,'color','white')
xlabel('k')
ylabel('|a_k|')

subplot(2,1,2)
stem(k,Ph)
set(gcf,'color','white')
xlabel('k')
ylabel('arg\{a_k\}')