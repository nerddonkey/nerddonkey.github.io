clc
clear all
close all



%% Example 1
figure

% define discrete-time vector
n= -40:1:40;

x = exp(1i*n*0);
% plot
subplot(2,1,1)
stem(n,real(x),'k');
xlabel('Sample')
ylabel('Amplitude')
 title('Re\{$e^{jn*0}$\}','Interpreter','latex','FontSize',26)
grid on
box off
 
subplot(2,1,2)
stem(n,zeros(length(x),1),'k'); %due to machine precision otherwise something very small but not quite zero plotted
% set figure and axes options
% set figure and axes options
set(gcf,'Color','white')
xlabel('Sample')
ylabel('Amplitude')
title('Im\{$e^{jn*0}$\}','Interpreter','latex','FontSize',26);
%ax = gca;
%ax.XTick = [-10:1:10];
grid on
box off


%% Example 2
figure

% define discrete-time vector
n= -40:1:40;

x = exp(1i*n*pi/8);
% plot
subplot(2,1,1)
stem(n,real(x),'k');
% set figure and axes options
% set figure and axes options
set(gcf,'Color','white')
xlabel('Sample')
ylabel('Amplitude')
 title('Re\{$e^{jn*\pi/8}$\}','Interpreter','latex','FontSize',26)
 % highlight the period
grid on
box off
 hold on
nn=-7:1:8;
xx = cos(nn*pi/8);

stem(nn,xx,'r');



% plot
subplot(2,1,2)
stem(n,imag(x),'k');
xlabel('Sample')
ylabel('Amplitude')
title('Im\{$e^{jn*\pi/8}$\}','Interpreter','latex','FontSize',26);

 %ax = gca;
%ax.XTick = [-10:1:10];
grid on
box off

% highlight the period
hold on
nn=-7:1:8;
xx = sin(nn*pi/8);
% plot
stem(nn,xx,'r');







%% Example 3
figure

% define discrete-time vector
n= -40:1:40;

x = exp(1i*n*pi/4);
% plot
subplot(2,1,1)
stem(n,real(x),'k');
% set figure and axes options
% set figure and axes options
set(gcf,'Color','white')
xlabel('Sample')
ylabel('Amplitude')
 title('Re\{$e^{jn*\pi/4}$\}','Interpreter','latex','FontSize',26)

 
%ax = gca;
%ax.XTick = [-10:1:10];
grid on
box off
hold on

% highlight the period
nn=-3:1:4;
xx = cos(nn*pi/4);
% plot
stem(nn,xx,'r');


% plot
subplot(2,1,2)
stem(n,imag(x),'k');
% set figure and axes options
% set figure and axes options
set(gcf,'Color','white')
xlabel('Sample')
ylabel('Amplitude')
title('Im\{$e^{jn*\pi/4}$\}','Interpreter','latex','FontSize',26)
 
%ax = gca;
%ax.XTick = [-10:1:10];
grid on
box off
hold on

% highlight the period
hold on
nn=-3:1:4;
xx = sin(nn*pi/4);
% plot
stem(nn,xx,'r');



%% Example 4
figure

% define discrete-time vector
n= -40:1:40;

x = exp(1i*n*pi/2);
% plot
subplot(2,1,1)
stem(n,real(x),'k');
% set figure and axes options
% set figure and axes options
set(gcf,'Color','white')
xlabel('Sample')
ylabel('Amplitude')
 title('Re\{$e^{jn*\pi/2}\}$','Interpreter','latex','FontSize',26)

% highlight the period
hold on
nn=-1:1:2;
xx = cos(nn*pi/2);
% plot
stem(nn,xx,'r');

grid on
box off
hold on;

% plot
subplot(2,1,2)
stem(n,imag(x),'k');
% set figure and axes options
% set figure and axes options
set(gcf,'Color','white')
xlabel('Sample')
ylabel('Amplitude')
title('Im\{$e^{jn*\pi/2}$\}','Interpreter','latex','FontSize',26)
 
%ax = gca;
%ax.XTick = [-10:1:10];
grid on
box off
hold on

% highlight the period
hold on
nn=-1:1:2;
xx = sin(nn*pi/2);
% plot
stem(nn,xx,'r');

%% Example 5
figure

% define discrete-time vector
n= -40:1:40;

x = exp(1i*n*pi);
% plot
subplot(2,1,1)
stem(n,real(x),'k');
% set figure and axes options
% set figure and axes options
set(gcf,'Color','white')
xlabel('Sample')
ylabel('Amplitude')
 title('Re\{$e^{jn*\pi}$\}','Interpreter','latex','FontSize',26)
ax = gca;
ax.XTick = [-10:1:10];
grid on
box off
hold on

% highlight the period
hold on
nn=0:1:1;
xx = cos(nn*pi);
% plot
stem(nn,xx,'r');

% plot
subplot(2,1,2)
stem(n,zeros(length(x),1),'k'); %due to machine precision otherwise something very small but not quite zero plotted
% set figure and axes options
% set figure and axes options
set(gcf,'Color','white')
xlabel('Sample')
ylabel('Amplitude')
title('Im\{$e^{jn*\pi}$\}','Interpreter','latex','FontSize',26)
 
%ax = gca;
%ax.XTick = [-10:1:10];
grid on
box off
hold on

%% Example 6
figure

% define discrete-time vector
n= -40:1:40;

x = exp(1i*n*3*pi/2);
% plot
subplot(2,1,1)
stem(n,real(x),'k');
% set figure and axes options
% set figure and axes options
set(gcf,'Color','white')
xlabel('Sample')
ylabel('Amplitude')
 title('Re\{$e^{jn*3\pi/2}$\}','Interpreter','latex','FontSize',26)
ax = gca;
ax.XTick = [-10:1:10];
grid on
box off
hold on

% highlight the period
hold on
nn=-1:1:2;
xx = cos(nn*3*pi/2);
% plot
stem(nn,xx,'r');

% plot
subplot(2,1,2)
stem(n,imag(x),'k');
% set figure and axes options
% set figure and axes options
set(gcf,'Color','white')
xlabel('Sample')
ylabel('Amplitude')
title('Im\{$e^{jn*3\pi/2}$\}','Interpreter','latex','FontSize',26)
 
%ax = gca;
%ax.XTick = [-10:1:10];
grid on
box off
hold on


% highlight the period
hold on
nn=-1:1:2;
xx = sin(nn*3*pi/2);
% plot
stem(nn,xx,'r');





%% Example 7
figure

% define discrete-time vector
n= -40:1:40;

x = exp(1i*n*7*pi/4);
% plot
subplot(2,1,1)
stem(n,real(x),'k');
% set figure and axes options
% set figure and axes options
set(gcf,'Color','white')
xlabel('Sample')
ylabel('Amplitude')
 title('Re\{$e^{jn*7\pi/4}$\}','Interpreter','latex','FontSize',26)

 
%ax = gca;
%ax.XTick = [-10:1:10];
grid on
box off
hold on

% highlight the period
nn=-3:1:4;
xx = cos(nn*7*pi/4);
% plot
stem(nn,xx,'r');


% plot
subplot(2,1,2)
stem(n,imag(x),'k');
% set figure and axes options
% set figure and axes options
set(gcf,'Color','white')
xlabel('Sample')
ylabel('Amplitude')
title('Im\{$e^{jn*7\pi/4}$\}','Interpreter','latex','FontSize',26)
 
%ax = gca;
%ax.XTick = [-10:1:10];
grid on
box off
hold on

% highlight the period
hold on
nn=-3:1:4;
xx = sin(nn*7*pi/4);
% plot
stem(nn,xx,'r');





%% Example 8
figure

% define discrete-time vector
n= -40:1:40;

x = exp(1i*n*15*pi/8);
% plot
subplot(2,1,1)
stem(n,real(x),'k');
% set figure and axes options
% set figure and axes options
set(gcf,'Color','white')
xlabel('Sample')
ylabel('Amplitude')
 title('Re\{$e^{jn*15\pi/8}$\}','Interpreter','latex','FontSize',26)
 % highlight the period
grid on
box off
 hold on
nn=-7:1:8;
xx = cos(nn*15*pi/8);

stem(nn,xx,'r');



% plot
subplot(2,1,2)
stem(n,imag(x),'k');
xlabel('Sample')
ylabel('Amplitude')
title('Im\{$e^{jn*15\pi/8}$\}','Interpreter','latex','FontSize',26);

 %ax = gca;
%ax.XTick = [-10:1:10];
grid on
box off

% highlight the period
hold on
nn=-7:1:8;
xx = sin(nn*15*pi/8);
% plot
stem(nn,xx,'r');


%% Example 9
figure

% define discrete-time vector
n= -40:1:40;

x = exp(1i*2*pi*n);
% plot
subplot(2,1,1)
stem(n,real(x),'k');
xlabel('Sample')
ylabel('Amplitude')
 title('Re\{$e^{jn*2\pi}$\}','Interpreter','latex','FontSize',26)
grid on
box off
 
subplot(2,1,2)
stem(n,zeros(length(x),1),'k'); %due to machine precision otherwise something very small but not quite zero plotted
% set figure and axes options
% set figure and axes options
set(gcf,'Color','white')
xlabel('Sample')
ylabel('Amplitude')
title('Im\{$e^{jn*2\pi}$\}','Interpreter','latex','FontSize',26);
%ax = gca;
%ax.XTick = [-10:1:10];
grid on
box off



