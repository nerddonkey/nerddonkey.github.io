
close all
clc
clear all

alpha = 0.5;
w = -3*pi:0.01:3*pi;
H = 1./(1-alpha.*exp(-j.*w));

subplot(2,1,1)
plot(w,abs(H))
set(gcf,'Color','white')
xlabel('\omega (rad/s)')
ylabel('|H(e^{j \omega})|')
title('$H(e^{j \omega}) = \frac{1}{1-0.5 e^{-j \omega}}$','Interpreter','latex')
ax = gca;
ax.XTick = [ -pi -pi/2 0 pi/2 pi ];
ax.XTickLabel = {'-\pi', '\pi/2','0','\pi/2','\pi'};
grid on
axis([-3*pi 3*pi 0 Inf])

subplot(2,1,2)
plot(w,angle(H))
set(gcf,'Color','white')
xlabel('\omega (rad/s)')
ylabel('arg\{H(e^{j \omega})\}')
title('$H(e^{j \omega}) = \frac{1}{1-0.5 e^{-j \omega}}$','Interpreter','latex')
axis([-3*pi 3*pi -pi pi])
ax = gca;
ax.XTick = [ -pi -pi/2 0 pi/2 pi ];
ax.XTickLabel = {'-\pi', '\pi/2','0','\pi/2','\pi'};
ax.YTick = [ -pi -pi/2 0 pi/2 pi];
ax.YTickLabel = {'-\pi', '\pi/2','0','\pi/2','\pi'};
grid on