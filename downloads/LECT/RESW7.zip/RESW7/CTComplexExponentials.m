clc
clear all
close all

%% First example
% define discrete-time vector
t= -7:0.01:7;
x = exp(i*t);


% plot real part
subplot(2,3,1)
plot(t,real(x),'k');
% set figure and axes options
set(gcf,'Color','white')
xlabel('Time')
ylabel('Amplitude')
title('$\Re\{e^{j t}\}$','Interpreter','latex')
ax = gca;
ax.XTick = [ -4*pi -3*pi -2*pi -pi 0 pi 2*pi 3*pi 4*pi];
ax.XTickLabel = {'-4\pi','-3\pi','-2\pi','-\pi','0','\pi','2\pi','3\pi','4\pi'};
grid on
box off
hold on

% highlight the period
hold on
tt=0:0.1:2*pi
xx = exp(i*tt);
% plot
plot(tt,real(xx),'r');

% plot imaginary part
subplot(2,3,4)
plot(t,imag(x),'k');
% set figure and axes options
set(gcf,'Color','white')
xlabel('Time')
ylabel('Amplitude')
title('$\Im\{e^{j t}\}$','Interpreter','latex')
ax = gca;
ax.XTick = [ -4*pi -3*pi -2*pi -pi 0 pi 2*pi 3*pi 4*pi];
ax.XTickLabel = {'-4\pi','-3\pi','-2\pi','-\pi','0','\pi','2\pi','3\pi','4\pi'};
grid on
box off
hold on

% % highlight the period
hold on
tt=0:0.1:2*pi
xx = exp(i*tt);
% plot
plot(tt,imag(xx),'r');

%% Second example
% define discrete-time vector
t= -7:0.01:7;
x = exp(i*2*pi*t);


% plot real part
subplot(2,3,2)
plot(t,real(x),'k');
% set figure and axes options
set(gcf,'Color','white')
xlabel('Time')
ylabel('Amplitude')
title('$\Re\{e^{j 2 \pi t}\}$','Interpreter','latex')
ax = gca;
ax.XTick = [ -4*pi -3*pi -2*pi -pi 0 pi 2*pi 3*pi 4*pi];
ax.XTickLabel = {'-4\pi','-3\pi','-2\pi','-\pi','0','\pi','2\pi','3\pi','4\pi'};
grid on
box off
hold on

% highlight the period
hold on
tt=0:0.1:1
xx = exp(i*2*pi*tt);
% plot
plot(tt,real(xx),'r');

% plot imaginary part
subplot(2,3,5)
plot(t,imag(x),'k');
% set figure and axes options
set(gcf,'Color','white')
xlabel('Time')
ylabel('Amplitude')
title('$\Im\{e^{j 2 \pi t}\}$','Interpreter','latex')
ax = gca;
ax.XTick = [ -4*pi -3*pi -2*pi -pi 0 pi 2*pi 3*pi 4*pi];
ax.XTickLabel = {'-4\pi','-3\pi','-2\pi','-\pi','0','\pi','2\pi','3\pi','4\pi'};
grid on
box off
hold on

% % highlight the period
hold on
tt=0:0.1:1
xx = exp(i*2*pi*tt);
% plot
plot(tt,imag(xx),'r');

%% Third example
% define discrete-time vector
t= -7:0.01:7;
x = exp(i*4*pi*t);


% plot real part
subplot(2,3,3)
plot(t,real(x),'k');
% set figure and axes options
set(gcf,'Color','white')
xlabel('Time')
ylabel('Amplitude')
title('$\Re\{e^{j 4 \pi t}\}$','Interpreter','latex')
ax = gca;
ax.XTick = [ -4*pi -3*pi -2*pi -pi 0 pi 2*pi 3*pi 4*pi];
ax.XTickLabel = {'-4\pi','-3\pi','-2\pi','-\pi','0','\pi','2\pi','3\pi','4\pi'};
grid on
box off
hold on

% highlight the period
hold on
tt=0:0.1:0.5
xx = exp(i*4*pi*tt);
% plot
plot(tt,real(xx),'r');

% plot imaginary part
subplot(2,3,6)
plot(t,imag(x),'k');
% set figure and axes options
set(gcf,'Color','white')
xlabel('Time')
ylabel('Amplitude')
title('$\Im\{e^{j 4 \pi t}\}$','Interpreter','latex')
ax = gca;
ax.XTick = [ -4*pi -3*pi -2*pi -pi 0 pi 2*pi 3*pi 4*pi];
ax.XTickLabel = {'-4\pi','-3\pi','-2\pi','-\pi','0','\pi','2\pi','3\pi','4\pi'};
grid on
box off
hold on

% % highlight the period
hold on
tt=0:0.1:0.5
xx = exp(i*4*pi*tt);
% plot
plot(tt,imag(xx),'r');

