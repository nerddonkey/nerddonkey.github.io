
close all
clc
clear all

w = -10:0.1:10;
H = 1./(1+j.*w);

subplot(2,1,1)
plot(w,abs(H))
set(gcf,'Color','white')
xlabel('\omega (rad/s)')
ylabel('|H(j \omega)|')
title('$H(j \omega) = \frac{1}{1+j \omega}$','Interpreter','latex')
grid on

subplot(2,1,2)
plot(w,angle(H))
set(gcf,'Color','white')
xlabel('\omega (rad/s)')
ylabel('arg\{H(j \omega)\}')
title('$H(j \omega) = \frac{1}{1+j \omega}$','Interpreter','latex')
ax = gca;
% ax.YTick = [-pi/2 0 pi/2];
ax.YTickLabel = {'-2\pi','-\pi','0','\pi','2\pi'};
grid on