
%% x = exp(1i*n*pi/8);
figure

% define discrete-time vector
n= -40:1:40;

x = exp(1i*n*pi/8);
% plot
subplot(2,1,1)
stem(n,real(x),'k');
% set figure and axes options
% set figure and axes options
set(gcf,'Color','white')
xlabel('Sample')
ylabel('Amplitude')
 title('Re\{$e^{jn*\pi/8}$\}','Interpreter','latex','FontSize',26)
 % highlight the period
grid on
box off
 hold on
nn=-7:1:8;
xx = cos(nn*pi/8);

stem(nn,xx,'r');



% plot
subplot(2,1,2)
stem(n,imag(x),'k');
xlabel('Sample')
ylabel('Amplitude')
title('Im\{$e^{jn*\pi/8}$\}','Interpreter','latex','FontSize',26);

 %ax = gca;
%ax.XTick = [-10:1:10];
grid on
box off

% highlight the period
hold on
nn=-7:1:8;
xx = sin(nn*pi/8);
% plot
stem(nn,xx,'r');


%% x = exp(1i*n*17*pi/8);
figure

% define discrete-time vector
n= -40:1:40;

x = exp(1i*n*17*pi/8);
% plot
subplot(2,1,1)
stem(n,real(x),'k');
% set figure and axes options
% set figure and axes options
set(gcf,'Color','white')
xlabel('Sample')
ylabel('Amplitude')
 title('Re\{$e^{jn*17\pi/8}$\}','Interpreter','latex','FontSize',26)
 % highlight the period
grid on
box off
 hold on
nn=-7:1:8;
xx = cos(nn*pi/8);

stem(nn,xx,'r');



% plot
subplot(2,1,2)
stem(n,imag(x),'k');
xlabel('Sample')
ylabel('Amplitude')
title('Im\{$e^{jn*17\pi/8}$\}','Interpreter','latex','FontSize',26);

 %ax = gca;
%ax.XTick = [-10:1:10];
grid on
box off

% highlight the period
hold on
nn=-7:1:8;
xx = sin(nn*pi/8);
% plot
stem(nn,xx,'r');


