%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [x2,a2] = TimeShiftFourierSeries(t0,T,T1,K,tmax,plotON)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Descrption: ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% x2 is the time-shifted (by t0) rectangular pulse (in the time domain) with
% width T1 and fundamental period T. The associated Fourier Series Coeffecients
% are stored in a2.
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
omega0   = 2*pi/T;              % fundamental frequency (radians/sec)
t        = [-tmax:0.01:tmax];   % define points along time axis
k        = [-K:K];              % max number of Fourier Series Coefficients
k(K+1)   = 0.0001;
a1       = sin(k.*omega0.*T1)./(k.*pi);
k(K+1)   = 0;

shift_multiplier = ?;           %[REPLACE ? with the right multiplier expression]

a2       = a1.*shift_multiplier;

x1       = a1*exp(1i*omega0*k'*t);
x2       = a2*exp(1i*omega0*k'*t);
% Plotting ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
if (plotON==1)
    figure;
    subplot(2,1,1); stem(k,real(a1),'b','LineWidth',1.5); hold on;
                    stem(k,real(a2),'r','LineWidth',1.5); grid on;
                    title(strcat('Number of Fourier Series Coeffecients =',num2str(K)));
                    xlim([-max(K),max(K)]); xlabel('k')
                    legend('x(t) Fourier Series Coeffecients',...
                           strcat('x(t-',num2str(t0),') Fourier Series Coeffecients'));
    
    subplot(2,1,2); plot(t,real(x1),'b',t,real(x2),'r','LineWidth',1.5);
                    title(strcat('x(t-',num2str(t0),')'));
                    xlim([-tmax,tmax]); grid on;
                    xlabel('Time'); ylabel('Amplitude');
                    legend('x(t)',...
                           strcat('x(t-',num2str(t0),')'));
end
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~